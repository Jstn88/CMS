import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TournamentPublic = ({ tournament }) => {
  const [page, setPage] = useState(null);

  useEffect(() => {
    fetchPage();
  }, [tournament._id]);

  const fetchPage = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/public/tournaments/${tournament._id}/page`);
      setPage(res.data);
    } catch (err) {
      console.error('Fetch page failed:', err);
    }
  };

  return (
    <div className="tournament-public">
      <h2>{tournament.name}</h2>
      <p><strong>Game:</strong> {tournament.game}</p>
      <p><strong>Status:</strong> {tournament.status}</p>
      <p><strong>Start Date:</strong> {new Date(tournament.start_date).toLocaleString()}</p>
      {tournament.stream_url && <p><strong>Stream:</strong> <a href={tournament.stream_url} target="_blank" rel="noopener noreferrer">Watch Live</a></p>}
      {page && (
        <>
          {page.bannerImage && <img src={`http://localhost:3001/tournaments/${tournament._id}/upload/${page.bannerImage.fileId}`} alt={page.title} className="banner-image" />}
          <p>{page.description}</p>
          {page.sections.map((section, idx) => (
            <div key={idx}>
              {section.type === 'text' ? <p>{section.content}</p> : section.image && <img src={`http://localhost:3001/tournaments/${tournament._id}/upload/${section.image.fileId}`} alt={`Section ${idx}`} />}
            </div>
          ))}
        </>
      )}
    </div>
  );
};

export default TournamentPublic;
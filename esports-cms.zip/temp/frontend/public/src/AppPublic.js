import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AppPublic.css';
import TournamentPublic from './components/TournamentPublic';

const AppPublic = () => {
  const [tournaments, setTournaments] = useState([]);

  useEffect(() => {
    fetchTournaments();
  }, []);

  const fetchTournaments = async () => {
    try {
      const res = await axios.get('http://localhost:3001/public/tournaments');
      setTournaments(res.data);
    } catch (err) {
      console.error('Fetch public tournaments failed:', err);
    }
  };

  return (
    <div className="app-public">
      <header className="public-header">
        <h1>Esports Tournaments</h1>
      </header>
      <main className="public-content">
        <div className="tournament-grid">
          {tournaments.map((tournament) => (
            <TournamentPublic key={tournament._id} tournament={tournament} />
          ))}
        </div>
      </main>
    </div>
  );
};

export default AppPublic;
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useDrag, useDrop } from 'react-dnd';
import './Bracket.css'; // We'll add this below

const ItemTypes = {
  PARTICIPANT: 'participant',
};

const Participant = ({ name, seed, id, tournamentId, token, onDrop }) => {
  const [, drag] = useDrag({
    type: ItemTypes.PARTICIPANT,
    item: { id, name, seed },
  });

  return (
    <div ref={drag} className="participant">
      {name} (Seed: {seed || 'N/A'})
    </div>
  );
};

const Match = ({ match, rIdx, mIdx, tournament, teams, token, gameFormat, isLosers = false, updateBracket }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [player1, setPlayer1] = useState(match.player1 || 'TBD');
  const [player2, setPlayer2] = useState(match.player2 || 'TBD');
  const [winner, setWinner] = useState(match.winner || 'Pending');
  const [date, setDate] = useState(match.date ? new Date(match.date).toISOString().slice(0, 16) : '');
  const [seed1, setSeed1] = useState(match.seed1 || '');
  const [seed2, setSeed2] = useState(match.seed2 || '');

  const [{ isOver }, drop] = useDrop({
    accept: ItemTypes.PARTICIPANT,
    drop: (item) => {
      const target = player1 === 'TBD' ? 'player1' : player2 === 'TBD' ? 'player2' : null;
      if (target) {
        updateBracket(rIdx, mIdx, target, item.name, item.seed, isLosers);
        setPlayer1(target === 'player1' ? item.name : player1);
        setPlayer2(target === 'player2' ? item.name : player2);
        setSeed1(target === 'player1' ? item.seed : seed1);
        setSeed2(target === 'player2' ? item.seed : seed2);
      }
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  });

  const handleSave = async () => {
    try {
      await axios.post(`http://localhost:3001/tournaments/${tournament._id}/bracket`, {
        rIdx,
        mIdx,
        player1,
        player2,
        winner,
        date,
        seed1: Number(seed1) || null,
        seed2: Number(seed2) || null,
        isLosers,
      }, { headers: { Authorization: `Bearer ${token}` } });
      setIsEditing(false);
    } catch (err) {
      console.error('Match update failed:', err);
    }
  };

  const availableParticipants = tournament.is_team_based
    ? teams.filter(t => t.game === tournament.game)
    : tournament.active_teams.map(t => ({ name: t.name, seed: t.seed }));

  return (
    <div ref={drop} className={`bracket-match ${isOver ? 'drop-target' : ''}`}>
      {isEditing ? (
        <>
          <select value={player1} onChange={(e) => setPlayer1(e.target.value)}>
            <option value="TBD">TBD</option>
            {availableParticipants.map(p => <option key={p.name} value={p.name}>{p.name}</option>)}
          </select>
          <input type="number" value={seed1} onChange={(e) => setSeed1(e.target.value)} placeholder="Seed 1" min="1" />
          <span>vs</span>
          <select value={player2} onChange={(e) => setPlayer2(e.target.value)}>
            <option value="TBD">TBD</option>
            {availableParticipants.map(p => <option key={p.name} value={p.name}>{p.name}</option>)}
          </select>
          <input type="number" value={seed2} onChange={(e) => setSeed2(e.target.value)} placeholder="Seed 2" min="1" />
          <select value={winner} onChange={(e) => setWinner(e.target.value)}>
            <option value="Pending">Pending</option>
            {player1 !== 'TBD' && <option value={player1}>{player1}</option>}
            {player2 !== 'TBD' && <option value={player2}>{player2}</option>}
          </select>
          <input type="datetime-local" value={date} onChange={(e) => setDate(e.target.value)} />
          <button onClick={handleSave} className="test-button">Save</button>
          <button onClick={() => setIsEditing(false)} className="test-button">Cancel</button>
        </>
      ) : (
        <>
          <span>{player1} (Seed: {seed1 || 'N/A'}) vs {player2} (Seed: {seed2 || 'N/A'})</span>
          <p>Winner: {winner}</p>
          <p>Scheduled: {date ? new Date(date).toLocaleString() : 'Not Set'}</p>
          <button onClick={() => setIsEditing(true)} className="test-button">Edit</button>
        </>
      )}
    </div>
  );
};

const Bracket = ({ bracket, tournament, games, token, teams, updateBracket }) => {
  const game = games.find(g => g.game_name === tournament.game) || { competitive_format: 'Unknown' };
  const format = game.competitive_format;

  const renderMatches = (rounds, isLosers = false) => (
    rounds.map((round, rIdx) => (
      <div key={rIdx} className="bracket-round">
        <h4>Round {rIdx + 1}</h4>
        {round.map((match, mIdx) => (
          <Match
            key={mIdx}
            match={match}
            rIdx={rIdx}
            mIdx={mIdx}
            tournament={tournament}
            teams={teams}
            token={token}
            gameFormat={format}
            isLosers={isLosers}
            updateBracket={updateBracket}
          />
        ))}
      </div>
    ))
  );

  const participants = tournament.is_team_based
    ? teams.filter(t => tournament.active_teams.some(at => at._id.toString() === t._id.toString()))
    : tournament.active_teams.map(t => ({ name: t.name, seed: t.seed, id: t._id }));

  return (
    <div className="bracket-container">
      <h4>{format} Bracket</h4>
      <div className="participant-pool">
        <h5>Participants</h5>
        {participants.map((p, idx) => (
          <Participant
            key={idx}
            name={p.name}
            seed={p.seed}
            id={p._id || p.name}
            tournamentId={tournament._id}
            token={token}
            onDrop={(item) => updateBracket(0, 0, 'player1', item.name, item.seed)} // Placeholder for initial drop
          />
        ))}
      </div>
      <div className="bracket-grid">
        {renderMatches(bracket.rounds)}
        {bracket.type === 'double_elimination' && (
          <>
            <h4>Winners Bracket</h4>
            {renderMatches(bracket.winners || [])}
            <h4>Losers Bracket</h4>
            {renderMatches(bracket.losers || [], true)}
            <h4>Grand Final</h4>
            {bracket.grandFinal && (
              <Match
                match={bracket.grandFinal}
                rIdx={0}
                mIdx={0}
                tournament={tournament}
                teams={teams}
                token={token}
                gameFormat={format}
                updateBracket={(rIdx, mIdx, field, value, seed) => updateBracket(rIdx, mIdx, field, value, seed, false)}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Bracket;
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Bracket from './Bracket';
import { Link } from 'react-router-dom';

const TournamentCard = ({ tournament, renderMessages, handleDonate, donationAmount, setDonationAmount, handleMessageSubmit, newMessage, setNewMessage, handleUpload, games, token, teams, handleRegister }) => {
  const [game, setGame] = useState(tournament.game);
  const [bracketType, setBracketType] = useState(tournament.bracket.type);
  const [streamUrl, setStreamUrl] = useState(tournament.stream_url || '');
  const [prizePool, setPrizePool] = useState(tournament.prize_pool);
  const [analytics, setAnalytics] = useState(null);

  useEffect(() => {
    fetchAnalytics();
  }, [tournament._id]);

  const fetchAnalytics = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/tournaments/${tournament._id}/analytics`, { headers: { Authorization: `Bearer ${token}` } });
      setAnalytics(res.data);
    } catch (err) {
      console.error('Analytics fetch failed:', err);
    }
  };

  const handleUpdate = async (field, value) => {
    try {
      await axios.put(`http://localhost:3001/tournaments/${tournament._id}`, { [field]: value }, { headers: { Authorization: `Bearer ${token}` } });
      if (field === 'game') setGame(value);
      if (field === 'bracket.type') setBracketType(value);
      if (field === 'stream_url') setStreamUrl(value);
      if (field === 'prize_pool') setPrizePool(value);
    } catch (err) {
      console.error('Update failed:', err);
    }
  };

  const updateBracket = async (rIdx, mIdx, field, value, seed, isLosers = false) => {
    const updatedMatch = field === 'player1' || field === 'player2'
      ? { player1: field === 'player1' ? value : tournament.bracket.rounds[rIdx][mIdx].player1, player2: field === 'player2' ? value : tournament.bracket.rounds[rIdx][mIdx].player2, seed1: field === 'player1' ? seed : tournament.bracket.rounds[rIdx][mIdx].seed1, seed2: field === 'player2' ? seed : tournament.bracket.rounds[rIdx][mIdx].seed2 }
      : { [field]: value };
    try {
      await axios.post(`http://localhost:3001/tournaments/${tournament._id}/bracket`, {
        rIdx,
        mIdx,
        ...updatedMatch,
        isLosers,
      }, { headers: { Authorization: `Bearer ${token}` } });
    } catch (err) {
      console.error('Bracket update failed:', err);
    }
  };

  return (
    <div className="tournament-card">
      <h2>{tournament.name}</h2>
      <div className="tournament-details">
        <div>
          <label>Game:</label>
          <select value={game} onChange={(e) => handleUpdate('game', e.target.value)}>
            {games.map((g) => <option key={g.game_name} value={g.game_name}>{g.game_name}</option>)}
          </select>
        </div>
        <p>Status: {tournament.status}</p>
        <div>
          <label>Bracket Type:</label>
          <select value={bracketType} onChange={(e) => handleUpdate('bracket.type', e.target.value)}>
            <option value="single_elimination">Single Elimination</option>
            <option value="double_elimination">Double Elimination</option>
          </select>
        </div>
        <div>
          <label>Stream URL:</label>
          <input type="url" value={streamUrl} onChange={(e) => setStreamUrl(e.target.value)} onBlur={() => handleUpdate('stream_url', streamUrl)} />
        </div>
        <div>
          <label>Prize Pool:</label>
          <input type="number" value={prizePool} onChange={(e) => setPrizePool(e.target.value)} onBlur={() => handleUpdate('prize_pool', Number(prizePool))} />
        </div>
      </div>
      <div className="funding-section">
        <p>Funds: ${tournament.current_funds} / ${tournament.crowdfunding_goal}</p>
        <progress value={tournament.current_funds} max={tournament.crowdfunding_goal}></progress>
        <div className="donate-form">
          <input type="number" value={donationAmount} onChange={(e) => setDonationAmount(e.target.value)} placeholder="Amount" className="donation-input" />
          <button onClick={() => handleDonate(tournament._id)} className="test-button">Donate</button>
        </div>
        <p>Prize Pool: ${tournament.prize_pool}</p>
        <ul>{tournament.prize_distribution.map((p, i) => <li key={i}>Rank {p.rank}: ${p.amount}</li>)}</ul>
      </div>
      <Link to={`/tournaments/${tournament._id}/page`} className="test-button">Edit Event Page</Link>
      {tournament.stream_url && <div><a href={tournament.stream_url} target="_blank" rel="noopener noreferrer">Watch Live</a></div>}
      <Bracket
        bracket={tournament.bracket}
        tournament={tournament}
        games={games}
        token={token}
        teams={teams}
        updateBracket={updateBracket}
      />
      <div>
        <h4>Register</h4>
        {tournament.is_team_based ? (
          <select onChange={(e) => handleRegister(tournament._id, e.target.value)}>
            <option value="">Select Team</option>
            {teams.filter(t => t.game === tournament.game).map(t => <option key={t._id} value={t._id}>{t.name}</option>)}
          </select>
        ) : (
          <button onClick={() => handleRegister(tournament._id)} className="test-button">Register Player</button>
        )}
        <p>Participants: {tournament.is_team_based ? tournament.active_teams.length : tournament.active_players}</p>
      </div>
      <div className="forum-section">
        <h4>Forum</h4>
        {renderMessages(tournament._id)}
        <form onSubmit={(e) => handleMessageSubmit(tournament._id, e)} className="forum-form">
          <input type="text" value={newMessage.message} onChange={(e) => setNewMessage({ ...newMessage, message: e.target.value })} placeholder="Type a message" />
          <select value={newMessage.type} onChange={(e) => setNewMessage({ ...newMessage, type: e.target.value })}>
            <option value="discussion">Discussion</option>
            <option value="announcement">Announcement</option>
          </select>
          <button type="submit" className="test-button">Send</button>
        </form>
      </div>
      <div className="upload-list">
        <h4>Uploads</h4>
        {tournament.uploads.length > 0 ? tournament.uploads.map((upload, idx) => (
          <a key={idx} href={`http://localhost:3001/tournaments/${tournament._id}/upload/${upload.fileId}`} download={upload.filename} className="upload-link">{upload.filename}</a>
        )) : <p>No uploads available.</p>}
        <input type="file" onChange={(e) => handleUpload(tournament._id, e.target.files[0])} className="upload-input" />
      </div>
      <div className="analytics-section">
        <h4>Analytics</h4>
        {analytics && (
          <>
            <p>Participants: {analytics.participants}</p>
            <p>Funds Raised: ${analytics.funds}</p>
            <p>Prize Pool: ${analytics.prizePool}</p>
            <p>Matches Played: {analytics.matchesPlayed}/{analytics.totalMatches}</p>
          </>
        )}
      </div>
    </div>
  );
};

export default TournamentCard;
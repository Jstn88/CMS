import React from 'react';

const PlayerCard = ({ player }) => (
  <div className="player-card">
    <h2>{player?.username || 'Unknown'}</h2>
    <p>Email: {player?.email || 'N/A'}</p>
  </div>
);

export default PlayerCard;
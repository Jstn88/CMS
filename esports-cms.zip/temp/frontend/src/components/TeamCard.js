import React, { useState } from 'react';
import axios from 'axios';

const TeamCard = ({ team, token }) => {
  const [name, setName] = useState(team.name);
  const [members, setMembers] = useState(team.members.map(m => m.username));
  const [seed, setSeed] = useState(team.seed || '');
  const [isEditing, setIsEditing] = useState(false);

  const handleUpdate = async () => {
    try {
      await axios.put(`http://localhost:3001/teams/${team._id}`, { name, memberUsernames: members }, { headers: { Authorization: `Bearer ${token}` } });
      if (seed !== team.seed) {
        await axios.post(`http://localhost:3001/tournaments/${team.tournaments[0]}/seed`, { teamId: team._id, seed: Number(seed) }, { headers: { Authorization: `Bearer ${token}` } });
      }
      setIsEditing(false);
    } catch (err) {
      console.error('Team update failed:', err);
    }
  };

  return (
    <div className="team-card">
      <h2>{team.name}</h2>
      {isEditing ? (
        <>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
          <select multiple value={members} onChange={(e) => setMembers(Array.from(e.target.selectedOptions, option => option.value))}>
            {team.members.map(m => <option key={m._id} value={m.username}>{m.username}</option>)}
          </select>
          <input type="number" value={seed} onChange={(e) => setSeed(e.target.value)} placeholder="Seed" />
          <button onClick={handleUpdate} className="test-button">Save</button>
          <button onClick={() => setIsEditing(false)} className="test-button">Cancel</button>
        </>
      ) : (
        <>
          <p>Captain: {team.captain.username}</p>
          <p>Members: {team.members.map(m => m.username).join(', ')}</p>
          <p>Game: {team.game}</p>
          <p>Seed: {team.seed || 'Not Set'}</p>
          <button onClick={() => setIsEditing(true)} className="test-button">Edit</button>
        </>
      )}
    </div>
  );
};

export default TeamCard;
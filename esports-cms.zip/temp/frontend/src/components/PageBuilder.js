import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const PageBuilder = ({ token }) => {
  const { id } = useParams();
  const [page, setPage] = useState({ title: '', description: '', sections: [], theme: 'dark' });
  const [bannerImage, setBannerImage] = useState(null);
  const [sectionImages, setSectionImages] = useState([]);

  useEffect(() => {
    fetchPage();
  }, [id]);

  const fetchPage = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/tournaments/${id}/page`, { headers: { Authorization: `Bearer ${token}` } });
      setPage(res.data || { title: '', description: '', sections: [], theme: 'dark' });
    } catch (err) {
      console.error('Page fetch failed:', err.response?.data || err.message);
    }
  };

  const handleSavePage = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('title', page.title);
    formData.append('description', page.description);
    formData.append('sections', JSON.stringify(page.sections));
    formData.append('theme', page.theme);
    if (bannerImage) formData.append('bannerImage', bannerImage);
    sectionImages.forEach((img, i) => formData.append('sectionImages', img));
    try {
      await axios.post(`http://localhost:3001/tournaments/${id}/page`, formData, { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'multipart/form-data' } });
      fetchPage();
      setBannerImage(null);
      setSectionImages([]);
    } catch (err) {
      console.error('Page save failed:', err.response?.data || err.message);
    }
  };

  const addSection = () => {
    setPage({ ...page, sections: [...page.sections, { type: 'text', content: '' }] });
  };

  const updateSection = (index, field, value) => {
    const newSections = [...page.sections];
    newSections[index][field] = value;
    setPage({ ...page, sections: newSections });
  };

  const handleSectionImage = (index, file) => {
    const newImages = [...sectionImages];
    newImages[index] = file;
    setSectionImages(newImages);
  };

  const removeSection = (index) => {
    const newSections = page.sections.filter((_, i) => i !== index);
    const newImages = sectionImages.filter((_, i) => i !== index);
    setPage({ ...page, sections: newSections });
    setSectionImages(newImages);
  };

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Event Page Builder</h1></header>
      <section className="content-section page-builder">
        <form onSubmit={handleSavePage} className="page-form">
          <div className="form-group">
            <label>Title:</label>
            <input type="text" value={page.title} onChange={(e) => setPage({ ...page, title: e.target.value })} placeholder="Page Title" required />
          </div>
          <div className="form-group">
            <label>Banner Image:</label>
            <input type="file" onChange={(e) => setBannerImage(e.target.files[0])} accept="image/*" />
            {page.bannerImage && (
              <p>Current: {page.bannerImage.filename} <a href={`http://localhost:3001/tournaments/${id}/upload/${page.bannerImage.fileId}`} target="_blank" rel="noopener noreferrer">View</a></p>
            )}
          </div>
          <div className="form-group">
            <label>Description:</label>
            <textarea value={page.description} onChange={(e) => setPage({ ...page, description: e.target.value })} placeholder="Event Description" rows="4" />
          </div>
          <div className="form-group">
            <label>Theme:</label>
            <select value={page.theme} onChange={(e) => setPage({ ...page, theme: e.target.value })}>
              <option value="dark">Dark</option>
              <option value="neon">Neon</option>
            </select>
          </div>
          <div className="section-list">
            <h4>Sections</h4>
            {page.sections.map((section, index) => (
              <div key={index} className="section-item">
                <select value={section.type} onChange={(e) => updateSection(index, 'type', e.target.value)}>
                  <option value="text">Text</option>
                  <option value="image">Image</option>
                </select>
                {section.type === 'text' ? (
                  <textarea value={section.content} onChange={(e) => updateSection(index, 'content', e.target.value)} placeholder="Section Content" rows="3" />
                ) : (
                  <>
                    <input type="file" onChange={(e) => handleSectionImage(index, e.target.files[0])} accept="image/*" />
                    {section.image && (
                      <p>Current: {section.image.filename} <a href={`http://localhost:3001/tournaments/${id}/upload/${section.image.fileId}`} target="_blank" rel="noopener noreferrer">View</a></p>
                    )}
                  </>
                )}
                <button type="button" onClick={() => removeSection(index)} className="test-button">Remove</button>
              </div>
            ))}
            <button type="button" onClick={addSection} className="test-button">Add Section</button>
          </div>
          <button type="submit" className="test-button">Save Page</button>
        </form>
      </section>
    </main>
  );
};

export default PageBuilder;
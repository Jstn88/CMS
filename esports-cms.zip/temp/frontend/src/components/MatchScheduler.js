import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const MatchScheduler = ({ token }) => {
  const { id } = useParams();
  const [schedule, setSchedule] = useState([]);
  const [newMatch, setNewMatch] = useState({ matchId: '', time: '', location: '' });

  useEffect(() => {
    fetchSchedule();
  }, [id]);

  const fetchSchedule = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/tournaments/${id}`, { headers: { Authorization: `Bearer ${token}` } });
      setSchedule(res.data.schedule || []);
    } catch (err) {
      console.error('Fetch schedule failed:', err);
    }
  };

  const handleAddMatch = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`http://localhost:3001/tournaments/${id}/schedule`, { matchId: newMatch.matchId, time: newMatch.time, location: newMatch.location }, { headers: { Authorization: `Bearer ${token}` } });
      setNewMatch({ matchId: '', time: '', location: '' });
      fetchSchedule();
    } catch (err) {
      console.error('Schedule update failed:', err);
    }
  };

  const sendReminder = async (matchId) => {
    try {
      // Simulate sending reminders (could integrate with email/SMS APIs later)
      const updatedSchedule = schedule.map(m => m.matchId === matchId ? { ...m, reminderSent: true } : m);
      setSchedule(updatedSchedule);
      console.log(`Reminder sent for match ${matchId}`);
    } catch (err) {
      console.error('Reminder failed:', err);
    }
  };

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Match Scheduler</h1></header>
      <section className="content-section schedule-section">
        <form onSubmit={handleAddMatch} className="schedule-form">
          <div className="form-group">
            <label>Match ID:</label>
            <input type="text" value={newMatch.matchId} onChange={(e) => setNewMatch({ ...newMatch, matchId: e.target.value })} placeholder="Match ID" required />
          </div>
          <div className="form-group">
            <label>Time:</label>
            <input type="datetime-local" value={newMatch.time} onChange={(e) => setNewMatch({ ...newMatch, time: e.target.value })} required />
          </div>
          <div className="form-group">
            <label>Location:</label>
            <input type="text" value={newMatch.location} onChange={(e) => setNewMatch({ ...newMatch, location: e.target.value })} placeholder="Online/Location" />
          </div>
          <button type="submit" className="test-button">Add Match</button>
        </form>
        <div className="schedule-list">
          <h3>Scheduled Matches</h3>
          {schedule.length === 0 ? (
            <p className="no-data">No matches scheduled.</p>
          ) : (
            schedule.map((match, idx) => (
              <div key={idx} className="schedule-item">
                <p><strong>Match ID:</strong> {match.matchId}</p>
                <p><strong>Time:</strong> {new Date(match.time).toLocaleString()}</p>
                <p><strong>Location:</strong> {match.location}</p>
                <p><strong>Reminder Sent:</strong> {match.reminderSent ? 'Yes' : 'No'}</p>
                {!match.reminderSent && <button onClick={() => sendReminder(match.matchId)} className="test-button">Send Reminder</button>}
              </div>
            ))
          )}
        </div>
      </section>
    </main>
  );
};

export default MatchScheduler;
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const Forum = ({ token }) => {
  const { id } = useParams();
  const [threads, setThreads] = useState([]);
  const [newThread, setNewThread] = useState({ title: '', content: '' });
  const [replies, setReplies] = useState({});
  const [selectedThread, setSelectedThread] = useState(null);
  const [newReply, setNewReply] = useState('');

  useEffect(() => {
    fetchThreads();
  }, [id]);

  const fetchThreads = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/tournaments/${id}`, { headers: { Authorization: `Bearer ${token}` } });
      setThreads(res.data.messages.filter(m => m.type === 'thread') || []);
    } catch (err) {
      console.error('Fetch threads failed:', err);
    }
  };

  const handleAddThread = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`http://localhost:3001/tournaments/${id}/messages`, { text: JSON.stringify({ title: newThread.title, content: newThread.content }), type: 'thread' }, { headers: { Authorization: `Bearer ${token}` } });
      setNewThread({ title: '', content: '' });
      fetchThreads();
    } catch (err) {
      console.error('Thread creation failed:', err);
    }
  };

  const handleAddReply = async (threadId, e) => {
    e.preventDefault();
    try {
      await axios.post(`http://localhost:3001/tournaments/${id}/messages`, { text: newReply, type: 'reply', parentId: threadId }, { headers: { Authorization: `Bearer ${token}` } });
      setNewReply('');
      fetchReplies(threadId);
    } catch (err) {
      console.error('Reply failed:', err);
    }
  };

  const fetchReplies = async (threadId) => {
    try {
      const res = await axios.get(`http://localhost:3001/tournaments/${id}/messages`, { headers: { Authorization: `Bearer ${token}` } });
      setReplies(prev => ({
        ...prev,
        [threadId]: res.data.messages.filter(m => m.type === 'reply' && m.parentId === threadId) || [],
      }));
    } catch (err) {
      console.error('Fetch replies failed:', err);
    }
  };

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Forum</h1></header>
      <section className="content-section forum-section">
        <form onSubmit={handleAddThread} className="forum-form">
          <div className="form-group">
            <label>Title:</label>
            <input type="text" value={newThread.title} onChange={(e) => setNewThread({ ...newThread, title: e.target.value })} placeholder="Thread Title" required />
          </div>
          <div className="form-group">
            <label>Content:</label>
            <textarea value={newThread.content} onChange={(e) => setNewThread({ ...newThread, content: e.target.value })} placeholder="Thread Content" rows="4" />
          </div>
          <button type="submit" className="test-button">Post Thread</button>
        </form>
        <div className="thread-list">
          <h3>Threads</h3>
          {threads.map((thread) => {
            const threadData = JSON.parse(thread.text);
            return (
              <div key={thread._id} className="thread-item" onClick={() => { setSelectedThread(thread._id); fetchReplies(thread._id); }}>
                <h4>{threadData.title}</h4>
                <p>{threadData.content}</p>
                <p>By: {thread.user} at {new Date(thread.timestamp).toLocaleString()}</p>
                {selectedThread === thread._id && (
                  <>
                    <div className="replies-list">
                      {replies[thread._id]?.map((reply) => (
                        <div key={reply._id} className="reply-item">
                          <p>{reply.text}</p>
                          <p>By: {reply.user} at {new Date(reply.timestamp).toLocaleString()}</p>
                        </div>
                      )) || <p>No replies yet.</p>}
                    </div>
                    <form onSubmit={(e) => handleAddReply(thread._id, e)} className="forum-form">
                      <input type="text" value={newReply} onChange={(e) => setNewReply(e.target.value)} placeholder="Reply..." />
                      <button type="submit" className="test-button">Reply</button>
                    </form>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </main>
  );
};

export default Forum;
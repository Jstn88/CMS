import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const TeamRoster = ({ token }) => {
  const { id } = useParams();
  const [team, setTeam] = useState(null);
  const [newRole, setNewRole] = useState({ member: '', role: '' });

  useEffect(() => {
    fetchTeam();
  }, [id]);

  const fetchTeam = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/teams/${id}`, { headers: { Authorization: `Bearer ${token}` } });
      setTeam(res.data);
    } catch (err) {
      console.error('Fetch team failed:', err);
    }
  };

  const handleAddRole = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:3001/teams/${id}`, { roles: [...team.roles, newRole] }, { headers: { Authorization: `Bearer ${token}` } });
      setNewRole({ member: '', role: '' });
      fetchTeam();
    } catch (err) {
      console.error('Role addition failed:', err);
    }
  };

  if (!team) return <div className="loading">Loading...</div>;

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Team Roster</h1></header>
      <section className="content-section roster-section">
        <h2>{team.name}</h2>
        <p><strong>Game:</strong> {team.game}</p>
        <p><strong>Captain:</strong> {team.captain.username}</p>
        <div className="roster-grid">
          {team.members.map((member) => (
            <div key={member._id} className="roster-item">
              <p><strong>Member:</strong> {member.username}</p>
              <p><strong>Role:</strong> {team.roles.find(r => r.member.toString() === member._id.toString())?.role || 'Member'}</p>
            </div>
          ))}
        </div>
        <form onSubmit={handleAddRole} className="team-form">
          <div className="form-group">
            <label>Member Username:</label>
            <input type="text" value={newRole.member} onChange={(e) => setNewRole({ ...newRole, member: e.target.value })} placeholder="Member Username" />
          </div>
          <div className="form-group">
            <label>Role:</label>
            <input type="text" value={newRole.role} onChange={(e) => setNewRole({ ...newRole, role: e.target.value })} placeholder="Role (e.g., Captain, Support)" />
          </div>
          <button type="submit" className="test-button">Add Role</button>
        </form>
      </section>
    </main>
  );
};

export default TeamRoster;
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const SponsorManager = ({ token }) => {
  const { id } = useParams();
  const [sponsors, setSponsors] = useState([]);
  const [newSponsor, setNewSponsor] = useState({ name: '', url: '', contribution: '', logo: null });

  useEffect(() => {
    fetchSponsors();
  }, [id]);

  const fetchSponsors = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/tournaments/${id}/sponsors`, { headers: { Authorization: `Bearer ${token}` } });
      setSponsors(res.data);
    } catch (err) {
      console.error('Fetch sponsors failed:', err);
    }
  };

  const handleAddSponsor = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', newSponsor.name);
    formData.append('url', newSponsor.url);
    formData.append('contribution', newSponsor.contribution);
    if (newSponsor.logo) formData.append('logo', newSponsor.logo);
    try {
      await axios.post(`http://localhost:3001/tournaments/${id}/sponsors`, formData, { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'multipart/form-data' } });
      setNewSponsor({ name: '', url: '', contribution: '', logo: null });
      fetchSponsors();
    } catch (err) {
      console.error('Sponsor creation failed:', err);
    }
  };

  const handleUpdateSponsor = async (sponsorId, updates) => {
    try {
      await axios.put(`http://localhost:3001/tournaments/${id}/sponsors/${sponsorId}`, updates, { headers: { Authorization: `Bearer ${token}` } });
      fetchSponsors();
    } catch (err) {
      console.error('Sponsor update failed:', err);
    }
  };

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Sponsor Manager</h1></header>
      <section className="content-section sponsor-section">
        <form onSubmit={handleAddSponsor} className="sponsor-form">
          <div className="form-group">
            <label>Name:</label>
            <input type="text" value={newSponsor.name} onChange={(e) => setNewSponsor({ ...newSponsor, name: e.target.value })} placeholder="Sponsor Name" required />
          </div>
          <div className="form-group">
            <label>URL:</label>
            <input type="url" value={newSponsor.url} onChange={(e) => setNewSponsor({ ...newSponsor, url: e.target.value })} placeholder="Sponsor Website" />
          </div>
          <div className="form-group">
            <label>Contribution ($):</label>
            <input type="number" value={newSponsor.contribution} onChange={(e) => setNewSponsor({ ...newSponsor, contribution: e.target.value })} placeholder="Contribution Amount" />
          </div>
          <div className="form-group">
            <label>Logo:</label>
            <input type="file" onChange={(e) => setNewSponsor({ ...newSponsor, logo: e.target.files[0] })} accept="image/*" />
          </div>
          <button type="submit" className="test-button">Add Sponsor</button>
        </form>
        <div className="sponsor-grid">
          {sponsors.map((sponsor) => (
            <div key={sponsor._id} className="sponsor-card">
              <h3>{sponsor.name}</h3>
              <p><strong>URL:</strong> <a href={sponsor.url} target="_blank" rel="noopener noreferrer">{sponsor.url}</a></p>
              <p><strong>Contribution:</strong> ${sponsor.contribution}</p>
              {sponsor.logo && <p><strong>Logo:</strong> <a href={`http://localhost:3001/tournaments/${id}/upload/${sponsor.logo.fileId}`} target="_blank" rel="noopener noreferrer">{sponsor.logo.filename}</a></p>}
              <input type="number" placeholder="New Contribution" onBlur={(e) => handleUpdateSponsor(sponsor._id, { contribution: e.target.value })} />
            </div>
          ))}
        </div>
      </section>
    </main>
  );
};

export default SponsorManager;
import React, { useState } from 'react';
import axios from 'axios';
import TeamCard from './TeamCard';

const Teams = ({ teams, token }) => {
  const [newTeam, setNewTeam] = useState({ name: '', game: '', members: [] });

  const handleCreateTeam = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:3001/teams', { name: newTeam.name, game: newTeam.game, memberUsernames: newTeam.members }, { headers: { Authorization: `Bearer ${token}` } });
      setNewTeam({ name: '', game: '', members: [] });
      window.location.reload(); // Refresh to fetch updated teams
    } catch (err) {
      console.error('Team creation failed:', err);
    }
  };

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Teams</h1></header>
      <section className="content-section teams">
        <form onSubmit={handleCreateTeam} className="team-form">
          <div className="form-group">
            <label>Name:</label>
            <input type="text" value={newTeam.name} onChange={(e) => setNewTeam({ ...newTeam, name: e.target.value })} placeholder="Team Name" />
          </div>
          <div className="form-group">
            <label>Game:</label>
            <input type="text" value={newTeam.game} onChange={(e) => setNewTeam({ ...newTeam, game: e.target.value })} placeholder="Game" />
          </div>
          <div className="form-group">
            <label>Members (comma-separated):</label>
            <input type="text" value={newTeam.members.join(',')} onChange={(e) => setNewTeam({ ...newTeam, members: e.target.value.split(',') })} placeholder="Members" />
          </div>
          <button type="submit" className="test-button">Create Team</button>
        </form>
        <div className="teams-grid">
          {teams.map((team) => <TeamCard key={team._id} team={team} token={token} />)}
        </div>
      </section>
    </main>
  );
};

export default Teams;
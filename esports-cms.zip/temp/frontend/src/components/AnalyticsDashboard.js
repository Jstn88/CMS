import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { Bar } from 'react-chartjs-2'; // Install with `npm install react-chartjs-2 chart.js`
import Chart from 'chart.js/auto';

const AnalyticsDashboard = ({ token }) => {
  const { id } = useParams();
  const [analytics, setAnalytics] = useState(null);

  useEffect(() => {
    fetchAnalytics();
  }, [id]);

  const fetchAnalytics = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/tournaments/${id}/analytics`, { headers: { Authorization: `Bearer ${token}` } });
      setAnalytics(res.data);
    } catch (err) {
      console.error('Analytics fetch failed:', err);
    }
  };

  if (!analytics) return <div className="loading">Loading...</div>;

  const chartData = {
    labels: ['Participants', 'Funds', 'Matches Played', 'Engagement', 'Sponsors'],
    datasets: [{
      label: 'Tournament Metrics',
      data: [
        analytics.participants,
        analytics.funds,
        analytics.matchesPlayed,
        analytics.engagement,
        analytics.sponsors,
      ],
      backgroundColor: '#00b4d8',
      borderColor: '#0095c0',
      borderWidth: 1,
    }],
  };

  const chartOptions = {
    scales: { y: { beginAtZero: true } },
    plugins: { legend: { display: false } },
  };

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Analytics</h1></header>
      <section className="content-section analytics-section">
        <h2>Tournament Analytics</h2>
        <div className="analytics-grid">
          <div className="analytics-item"><span className="stat-label">Participants</span><span className="stat-value">{analytics.participants}</span></div>
          <div className="analytics-item"><span className="stat-label">Funds Raised</span><span className="stat-value">${analytics.funds.toFixed(2)}</span></div>
          <div className="analytics-item"><span className="stat-label">Prize Pool</span><span className="stat-value">${analytics.prizePool.toFixed(2)}</span></div>
          <div className="analytics-item"><span className="stat-label">Matches Played</span><span className="stat-value">{analytics.matchesPlayed}/{analytics.totalMatches}</span></div>
          <div className="analytics-item"><span className="stat-label">Engagement</span><span className="stat-value">{analytics.engagement}%</span></div>
          <div className="analytics-item"><span className="stat-label">Sponsors</span><span className="stat-value">{analytics.sponsors}</span></div>
          <div className="analytics-item"><span className="stat-label">Messages</span><span className="stat-value">{analytics.messages}</span></div>
          <div className="analytics-item"><span className="stat-label">Uploads</span><span className="stat-value">{analytics.uploads}</span></div>
        </div>
        <div className="chart-container">
          <h3>Performance Overview</h3>
          <Bar data={chartData} options={chartOptions} />
        </div>
      </section>
    </main>
  );
};

export default AnalyticsDashboard;
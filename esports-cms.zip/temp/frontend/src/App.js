import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import io from 'socket.io-client';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { BrowserRouter as Router, Route, Routes, Link, useNavigate, useLocation } from 'react-router-dom';
import './App.css';
import gamesData from './games.json';
import Dashboard from './pages/Dashboard';
import Tournaments from './pages/Tournaments';
import Teams from './pages/Teams';
import TournamentDetails from './pages/TournamentDetails';
import PageBuilder from './components/PageBuilder';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import MatchScheduler from './components/MatchScheduler';
import SponsorManager from './components/SponsorManager';
import Forum from './components/Forum';
import TeamRoster from './components/TeamRoster';

const socket = io('http://localhost:3001', { reconnectionAttempts: 5, reconnectionDelay: 1000 });

function TopBar({ username, role, onLogout }) {
  return (
    <div className="top-bar">
      <span className="user-info">Logged in as {username} ({role})</span>
      <button onClick={onLogout} className="logout-button">Logout</button>
    </div>
  );
}

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [tournaments, setTournaments] = useState([]);
  const [teams, setTeams] = useState([]);
  const [theme, setTheme] = useState('dark');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('organizer');
  const [donationAmount, setDonationAmount] = useState(''); // Moved here
  const [newMessage, setNewMessage] = useState({ message: '', type: 'discussion' }); // Moved here
  const [hasFetched, setHasFetched] = useState(false);
  const [games] = useState(gamesData);
  const navigate = useNavigate();

  const fetchTournaments = useCallback(async () => {
    if (!token) return;
    try {
      const res = await axios.get('http://localhost:3001/tournaments', { headers: { Authorization: `Bearer ${token}` } });
      setTournaments(res.data);
    } catch (err) {
      console.error('Fetch tournaments failed:', err);
    }
  }, [token]);

  const fetchTeams = useCallback(async () => {
    if (!token) return;
    try {
      const res = await axios.get('http://localhost:3001/teams', { headers: { Authorization: `Bearer ${token}` } });
      setTeams(res.data);
    } catch (err) {
      console.error('Fetch teams failed:', err);
    }
  }, [token]);

  const fetchUserRole = useCallback(async () => {
    if (!token) return;
    try {
      const res = await axios.get('http://localhost:3001/user/role', { headers: { Authorization: `Bearer ${token}` } });
      setRole(res.data.role);
      setUsername(res.data.username || 'User');
    } catch (err) {
      console.error('Fetch role failed:', err);
    }
  }, [token]);

  useEffect(() => {
    if (token && !hasFetched) {
      Promise.all([fetchTournaments(), fetchTeams(), fetchUserRole()]).then(() => setHasFetched(true));
      socket.on('connect', () => console.log('Socket connected'));
      socket.on('bracketUpdate', (updatedTournament) => setTournaments((prev) => prev.map(t => t._id === updatedTournament._id ? updatedTournament : t)));
      socket.on('messageUpdate', (updatedTournament) => setTournaments((prev) => prev.map(t => t._id === updatedTournament._id ? updatedTournament : t)));
      socket.on('scheduleUpdate', (updatedTournament) => setTournaments((prev) => prev.map(t => t._id === updatedTournament._id ? updatedTournament : t)));
    }
    return () => {
      socket.off('connect');
      socket.off('bracketUpdate');
      socket.off('messageUpdate');
      socket.off('scheduleUpdate');
    };
  }, [token, fetchTournaments, fetchTeams, fetchUserRole, hasFetched]);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      localStorage.removeItem('token');
      const res = await axios.post('http://localhost:3001/login', { username, password });
      const newToken = res.data.token;
      setToken(newToken);
      localStorage.setItem('token', newToken);
      setHasFetched(false);
      navigate('/dashboard');
    } catch (err) {
      console.error('Login failed:', err);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setRole('organizer');
    navigate('/');
  };

  const canAccess = (requiredRole) => {
    const roles = { organizer: 3, player: 2, spectator: 1 };
    return roles[role] >= roles[requiredRole];
  };

  if (!token) {
    return (
      <div className={`app-container ${theme}`}>
        <div className="login-container">
          <form onSubmit={handleLogin} className="auth-form">
            <div className="form-group">
              <label>Username:</label>
              <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" className="auth-input" />
            </div>
            <div className="form-group">
              <label>Password:</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="auth-input" />
            </div>
            <button type="submit" className="auth-button">Login</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <DndProvider backend={HTML5Backend}>
      <div className={`app-container ${theme}`}>
        <TopBar username={username} role={role} onLogout={handleLogout} />
        <nav className="sidebar">
          <h1 className="sidebar-title">Esports CMS</h1>
          <ul className="sidebar-menu">
            <li><Link to="/dashboard">Dashboard</Link></li>
            {canAccess('organizer') && <li><Link to="/tournaments">Tournaments</Link></li>}
            {canAccess('player') && <li><Link to="/teams">Teams</Link></li>}
            <li onClick={() => setTheme(theme === 'dark' ? 'neon' : 'dark')}>
              Toggle {theme === 'dark' ? 'Neon' : 'Dark'} Theme
            </li>
          </ul>
        </nav>
        <main className="main-content">
          <Routes>
            <Route path="/dashboard" element={<Dashboard tournaments={tournaments} teams={teams} role={role} token={token} />} />
            {canAccess('organizer') && <Route path="/tournaments" element={<Tournaments tournaments={tournaments} renderMessages={renderMessages} handleDonate={handleDonate} donationAmount={donationAmount} setDonationAmount={setDonationAmount} handleMessageSubmit={handleMessageSubmit} newMessage={newMessage} setNewMessage={setNewMessage} handleUpload={handleUpload} games={games} token={token} teams={teams} handleRegister={handleRegister} handleTournamentCreate={handleTournamentCreate} />} />}
            {canAccess('player') && <Route path="/teams" element={<Teams teams={teams} token={token} role={role} />} />}
            {canAccess('organizer') && <Route path="/tournaments/:id" element={<TournamentDetails token={token} />} />}
            {canAccess('organizer') && <Route path="/tournaments/:id/page" element={<PageBuilder token={token} />} />}
            {canAccess('organizer') && <Route path="/tournaments/:id/analytics" element={<AnalyticsDashboard token={token} />} />}
            {canAccess('organizer') && <Route path="/tournaments/:id/schedule" element={<MatchScheduler token={token} />} />}
            {canAccess('organizer') && <Route path="/tournaments/:id/sponsors" element={<SponsorManager token={token} />} />}
            {canAccess('spectator') && <Route path="/tournaments/:id/forum" element={<Forum token={token} />} />}
            {canAccess('player') && <Route path="/teams/:id/roster" element={<TeamRoster token={token} />} />}
            <Route path="/" element={<Dashboard tournaments={tournaments} teams={teams} role={role} token={token} />} />
          </Routes>
        </main>
      </div>
    </DndProvider>
  );

  function handleDonate(tournamentId) {
    try {
      axios.post(`http://localhost:3001/tournaments/${tournamentId}/donate`, { amount: donationAmount }, { headers: { Authorization: `Bearer ${token}` } })
        .then(() => {
          setDonationAmount('');
          fetchTournaments();
        })
        .catch(err => console.error('Donation failed:', err));
    } catch (err) {
      console.error('Donation failed:', err);
    }
  }

  function handleMessageSubmit(tournamentId, e) {
    e.preventDefault();
    try {
      axios.post(`http://localhost:3001/tournaments/${tournamentId}/messages`, { text: newMessage.message, type: newMessage.type }, { headers: { Authorization: `Bearer ${token}` } })
        .then(() => {
          setNewMessage({ message: '', type: 'discussion' });
          fetchTournaments();
        })
        .catch(err => console.error('Message submit failed:', err));
    } catch (err) {
      console.error('Message submit failed:', err);
    }
  }

  function handleUpload(tournamentId, file) {
    const formData = new FormData();
    formData.append('file', file);
    try {
      axios.post(`http://localhost:3001/tournaments/${tournamentId}/upload`, formData, { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'multipart/form-data' } })
        .then(() => fetchTournaments())
        .catch(err => console.error('Upload failed:', err));
    } catch (err) {
      console.error('Upload failed:', err);
    }
  }

  function handleRegister(tournamentId, teamId) {
    try {
      axios.post(`http://localhost:3001/tournaments/${tournamentId}/register`, { teamId }, { headers: { Authorization: `Bearer ${token}` } })
        .then(() => fetchTournaments())
        .catch(err => console.error('Registration failed:', err));
    } catch (err) {
      console.error('Registration failed:', err);
    }
  }

  function handleTournamentCreate(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      name: formData.get('name'),
      game: formData.get('game'),
      start_date: formData.get('start_date'),
      is_team_based: formData.get('is_team_based') === 'true',
      crowdfunding_goal: Number(formData.get('crowdfunding_goal')) || 0,
      prize_pool: Number(formData.get('prize_pool')) || 0,
      stream_url: formData.get('stream_url'),
      bracket_type: formData.get('bracket_type') || 'single_elimination',
    };
    try {
      axios.post('http://localhost:3001/tournaments', data, { headers: { Authorization: `Bearer ${token}` } })
        .then(() => fetchTournaments())
        .catch(err => console.error('Tournament creation failed:', err));
    } catch (err) {
      console.error('Tournament creation failed:', err);
    }
  }

  function renderMessages(tournamentId) {
    const tournament = tournaments.find((t) => t._id === tournamentId);
    if (!tournament?.messages) return <p className="no-data">No messages yet.</p>;
    return tournament.messages.map((msg, idx) => (
      <div key={idx} className={`chat-list rce-container ${msg.type}`}>
        <span className="rce-title">{msg.user}</span>: <span className="rce-subtitle">{msg.text}</span>
        <span className="rce-date">{new Date(msg.timestamp).toLocaleString()}</span>
      </div>
    ));
  }
}

export default function AppWrapper() {
  return <Router><App /></Router>;
}
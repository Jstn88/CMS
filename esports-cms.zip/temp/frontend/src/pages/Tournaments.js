import React from 'react';
import TournamentCard from '../components/TournamentCard';

const Tournaments = ({ tournaments, renderMessages, handleDonate, donationAmount, setDonationAmount, handleMessageSubmit, newMessage, setNewMessage, handleUpload, games, token, teams, handleRegister, handleTournamentCreate }) => {
  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Tournaments</h1></header>
      <section className="content-section tournaments">
        <form onSubmit={handleTournamentCreate} className="tournament-form">
          <div className="form-group">
            <label>Name:</label>
            <input type="text" name="name" placeholder="Tournament Name" required />
          </div>
          <div className="form-group">
            <label>Game:</label>
            <select name="game" required>
              <option value="">Select Game</option>
              {games.map(g => <option key={g.game_name} value={g.game_name}>{g.game_name}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Start Date:</label>
            <input type="datetime-local" name="start_date" required />
          </div>
          <div className="form-group">
            <label>Type:</label>
            <select name="is_team_based" required>
              <option value="true">Team-Based</option>
              <option value="false">Individual</option>
            </select>
          </div>
          <div className="form-group">
            <label>Bracket Type:</label>
            <select name="bracket_type" required>
              <option value="single_elimination">Single Elimination</option>
              <option value="double_elimination">Double Elimination</option>
              <option value="round_robin">Round Robin</option>
            </select>
          </div>
          <div className="form-group">
            <label>Crowdfunding Goal:</label>
            <input type="number" name="crowdfunding_goal" placeholder="Crowdfunding Goal" />
          </div>
          <div className="form-group">
            <label>Prize Pool:</label>
            <input type="number" name="prize_pool" placeholder="Prize Pool" />
          </div>
          <div className="form-group">
            <label>Stream URL:</label>
            <input type="url" name="stream_url" placeholder="Stream URL" />
          </div>
          <button type="submit" className="test-button">Create Tournament</button>
        </form>
        <div className="tournament-list">
          {tournaments.length === 0 ? (
            <p className="no-data">No tournaments available.</p>
          ) : (
            tournaments.map((tourney) => (
              <TournamentCard
                key={tourney._id}
                tournament={tourney}
                renderMessages={renderMessages}
                handleDonate={handleDonate}
                donationAmount={donationAmount}
                setDonationAmount={setDonationAmount}
                handleMessageSubmit={handleMessageSubmit}
                newMessage={newMessage}
                setNewMessage={setNewMessage}
                handleUpload={handleUpload}
                games={games}
                token={token}
                teams={teams}
                handleRegister={handleRegister}
              />
            ))
          )}
        </div>
      </section>
    </main>
  );
};

export default Tournaments;
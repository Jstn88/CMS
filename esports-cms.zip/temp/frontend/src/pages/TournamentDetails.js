import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import Bracket from '../components/Bracket';

const TournamentDetails = ({ token }) => {
  const { id } = useParams();
  const [tournament, setTournament] = useState(null);
  const [games] = useState(require('../games.json'));
  const [teams, setTeams] = useState([]);

  useEffect(() => {
    fetchTournament();
    fetchTeams();
  }, [id]);

  const fetchTournament = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/tournaments/${id}`, { headers: { Authorization: `Bearer ${token}` } });
      setTournament(res.data);
    } catch (err) {
      console.error('Fetch tournament failed:', err);
    }
  };

  const fetchTeams = async () => {
    try {
      const res = await axios.get('http://localhost:3001/teams', { headers: { Authorization: `Bearer ${token}` } });
      setTeams(res.data);
    } catch (err) {
      console.error('Fetch teams failed:', err);
    }
  };

  if (!tournament) return <div className="loading">Loading...</div>;

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">{tournament.name}</h1></header>
      <section className="content-section tournament-details-section">
        <h2>Details</h2>
        <p><strong>Game:</strong> {tournament.game}</p>
        <p><strong>Status:</strong> {tournament.status}</p>
        <p><strong>Start Date:</strong> {new Date(tournament.start_date).toLocaleString()}</p>
        <p><strong>Prize Pool:</strong> ${tournament.prize_pool}</p>
        <Bracket bracket={tournament.bracket} tournament={tournament} games={games} token={token} teams={teams} updateBracket={(rIdx, mIdx, field, value, seed, isLosers) => {}} />
      </section>
    </main>
  );
};

export default TournamentDetails;
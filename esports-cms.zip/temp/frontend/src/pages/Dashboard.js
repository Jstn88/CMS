import React from 'react';

const Dashboard = ({ tournaments, teams, role, token }) => {
  const canAccess = (requiredRole) => {
    const roles = { organizer: 3, player: 2, spectator: 1 };
    return roles[role] >= roles[requiredRole];
  };

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Organizer Dashboard</h1></header>
      <section className="content-section stats-dashboard">
        <h2>Stats Overview</h2>
        <div className="stats-grid">
          <div className="stat-item"><span className="stat-label">Tournaments</span><span className="stat-value">{tournaments.length}</span></div>
          <div className="stat-item"><span className="stat-label">Teams</span><span className="stat-value">{teams.length}</span></div>
          {canAccess('organizer') && <div className="stat-item"><span className="stat-label">Role</span><span className="stat-value">{role}</span></div>}
        </div>
      </section>
    </main>
  );
};

export default Dashboard;
import React, { useState } from 'react';
import axios from 'axios';
import TeamCard from '../components/TeamCard';

const Teams = ({ teams, token, role }) => {
  const canAccess = (requiredRole) => {
    const roles = { organizer: 3, player: 2, spectator: 1 };
    return roles[role] >= roles[requiredRole];
  };

  const [newTeam, setNewTeam] = useState({ name: '', game: '', members: [], roles: [] });

  const handleCreateTeam = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:3001/teams', { name: newTeam.name, game: newTeam.game, memberUsernames: newTeam.members, roles: newTeam.roles }, { headers: { Authorization: `Bearer ${token}` } });
      setNewTeam({ name: '', game: '', members: [], roles: [] });
      window.location.reload();
    } catch (err) {
      console.error('Team creation failed:', err);
    }
  };

  return (
    <main className="main-content">
      <header className="header"><h1 className="header-title">Teams</h1></header>
      <section className="content-section teams">
        {canAccess('player') && (
          <form onSubmit={handleCreateTeam} className="team-form">
            <div className="form-group">
              <label>Name:</label>
              <input type="text" value={newTeam.name} onChange={(e) => setNewTeam({ ...newTeam, name: e.target.value })} placeholder="Team Name" />
            </div>
            <div className="form-group">
              <label>Game:</label>
              <input type="text" value={newTeam.game} onChange={(e) => setNewTeam({ ...newTeam, game: e.target.value })} placeholder="Game" />
            </div>
            <div className="form-group">
              <label>Members (comma-separated):</label>
              <input type="text" value={newTeam.members.join(',')} onChange={(e) => setNewTeam({ ...newTeam, members: e.target.value.split(',') })} placeholder="Members" />
            </div>
            <div className="form-group">
              <label>Roles (e.g., JSON format):</label>
              <input 
                type="text" 
                value={JSON.stringify(newTeam.roles)} 
                onChange={(e) => setNewTeam({ ...newTeam, roles: JSON.parse(e.target.value.replace(/'/g, '"')) || [] })} 
                placeholder='[{"member": "username", "role": "role"}]'
                title='Example: [{"member": "username", "role": "role"}]'
              />
            </div>
            <button type="submit" className="test-button">Create Team</button>
          </form>
        )}
        <div className="teams-grid">
          {teams.map((team) => (
            <TeamCard key={team._id} team={team} token={token} role={role} />
          ))}
        </div>
      </section>
    </main>
  );
};

export default Teams;
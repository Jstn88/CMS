export const swissSeeding = (teams) => {
    return teams.sort((a, b) => b.elo - a.elo).map((team, index) => ({ ...team, seed: index + 1 }));
  };
  
  export const randomSeeding = (teams) => {
    for (let i = teams.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [teams[i], teams[j]] = [teams[j], teams[i]];
    }
    return teams.map((team, index) => ({ ...team, seed: index + 1 }));
  };
  
  export const manualSeeding = (teams, seeds) => {
    return teams.map(team => ({ ...team, seed: seeds[team._id] || null }));
  };